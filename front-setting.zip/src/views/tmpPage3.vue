<template>
  <!-- vuetify를 참고하여 작성하기
  https://vuetifyjs.com/ko/components/api-explorer
  -->
  <div>tmpPage3</div>
</template>

<script>
export default {
  components: {},
  name: "tmpPage3",

  created() {},
  methods: {},
  computed: {},
  data() {}
};
</script>

<style scoped></style>
