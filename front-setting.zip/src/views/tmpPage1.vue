<template>
  <!-- vuetify를 참고하여 작성하기
  https://vuetifyjs.com/ko/components/api-explorer
  -->
  <div>
    tmpPage1
    <input
      type="button"
      value="back에 no 3으로 testID값 얻기 위해 GET요청 보내기"
      @click="tmpFunction()"
    />
    <br />
    testID : "{{ testID }}"
  </div>
</template>

<script>
import Constant from "../vuex/Constant";

export default {
  components: {},
  name: "tmpPage1",

  created() {},
  methods: {
    tmpFunction() {
      this.$store.dispatch(Constant.GET_TEST, {
        no: 3
      });
    }
  },
  computed: {
    testID() {
      return this.$store.state.testID;
    }
  },
  data() {
    return {};
  }
};
</script>

<style scoped></style>
