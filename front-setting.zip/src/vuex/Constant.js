export default {
  GET_TEST: "getTest"
};
