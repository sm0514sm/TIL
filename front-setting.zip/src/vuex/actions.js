import Constant from "./Constant";
import http from "./http-common";

export default {
  [Constant.GET_TEST]: (store, payload) => {
    http
      .get("/gettest/" + payload.no)
      .then(response => {
        alert(response);
        store.commit(Constant.GET_TEST, {
          testID: response.data.testID
        });
      })
      .catch(exp => {
        alert("TEST에 실패하였습니다\n" + exp);
      });
  }
};
