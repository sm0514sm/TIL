package com.ssafy.model.dto;

import java.io.Serializable;

public class Product implements Serializable{
	private int no;
	private String id;
	private String title;
	private int price;
	private String description;
	
	/*---------- 생성자 ----------*/
	public Product() {}

	public Product(int no, String id, String title, int price, String text) {
		this.no = no;
		this.id = id;
		this.title = title;
		setPrice(price);
		setDescription(text);
	}
	
	
	public Product(String id, String title, int price, String description) {
		super();
		this.id = id;
		this.title = title;
		this.price = price;
		this.description = description;
	}

	

	/*---------- 메서드 ----------*/
	
	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}
	
	public String toString() {
		return id + "\t| " + title + "\t| " + price + "\t| " + description;
	}
	
	/*---------- get, set ----------*/
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		if (price < 0) {
			System.out.println("가격 설정을 잘못하셨습니다.\n0원으로 설정합니다.");
			this.price = 0;
		} else
			this.price = price;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
