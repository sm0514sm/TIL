package com.ssafy.model.dao;

import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductDAO {
	public Product search(int id);
	public List<Product> searchAll( );
	public void insert(Product product);
	public void update(Product product);
	public void delete(int id);
}












