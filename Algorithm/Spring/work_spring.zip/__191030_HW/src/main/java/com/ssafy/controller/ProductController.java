package com.ssafy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

//@Controller
public class ProductController {
	@Autowired
	private ProductService service;
	
	@ExceptionHandler
	public ModelAndView handler(Exception e) {
		ModelAndView mav = new ModelAndView("ErrorHandler");
		mav.addObject("msg", e.getMessage());
		return mav;
	}

	@GetMapping("productInput.do")
	public String productInput() {
		return "product/ProductInsert";
	}

	@PostMapping("productInsert.do")
	public String productInsert(Product product) {
		service.insert(product);
		return "redirect:productList.do";
	}

	@GetMapping("productList.do")
	public String productList(Model model) {
		model.addAttribute("list", service.searchAll());
		System.out.println("실행됨");
		return "ProductList";
	}

	@GetMapping("productSearch.do")
	public String productSearch(String no, Model model) {
		model.addAttribute("product", service.search(Integer.parseInt(no)));
		return "product/ProductSearch";
	}

	@GetMapping("productDelete.do")
	public String productDelete(String no) {
		service.delete(Integer.parseInt(no));
		return "redirect:productList.do";
	}

	@GetMapping("productUpdateForm.do")
	public String productUpdateForm(String no, Model model) {
		model.addAttribute("product", service.search(Integer.parseInt(no)));
		return "product/productUpdate";
	}

	@PostMapping("productUpdate.do")
	public String productUpdate(Product product) {
		service.update(product);
		return "redirect:productSearch.do?no=" + product.getNo();
	}
}
