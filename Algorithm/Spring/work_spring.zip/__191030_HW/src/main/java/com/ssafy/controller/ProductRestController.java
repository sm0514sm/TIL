package com.ssafy.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

/**
 * @RestController
 * REST Ful 서비스를 위한 컨트롤러로 @ResponseBody 어노테이션을 추가하지 않아도
 * 기본적으로 직접 출력 해 준다.
 */

@RestController
public class ProductRestController {
	@Autowired
	private ProductService service;
	
	@ExceptionHandler
	public ResponseEntity<Map<String,Object>> handle(Exception e){
		return handleFail(e.getMessage(), HttpStatus.OK);
	}
	
	@GetMapping("/searchAll")
	public ResponseEntity<Map<String, Object>> products(){
		List<Product> list = service.searchAll();
		return handleSuccess(list);
	}
	/*
	@GetMapping("/insert")
	public ResponseEntity<Map<String, Object>> productsInsert(){
		List<Product> list = service.searchAll();
		return handleSuccess(list);
	}
	@GetMapping("/update")
	public ResponseEntity<Map<String, Object>> productsUpdate(){
		List<Product> list = service.searchAll();
		return handleSuccess(list);
	}
	@GetMapping("/delete")
	public ResponseEntity<Map<String, Object>> productsDelete(){
		List<Product> list = service.searchAll();
		return handleSuccess(list);
	}
	*/
	public ResponseEntity<Map<String, Object>> handleFail(Object data, HttpStatus state){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state", "fail");
		resultMap.put("data", data);
		return new ResponseEntity<Map<String,Object>>(resultMap, state);
	}
	
	public ResponseEntity<Map<String, Object>> handleSuccess(Object data){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state", "ok");
		resultMap.put("data", data);
		return new ResponseEntity<Map<String,Object>>(resultMap, HttpStatus.OK);
	}
}
