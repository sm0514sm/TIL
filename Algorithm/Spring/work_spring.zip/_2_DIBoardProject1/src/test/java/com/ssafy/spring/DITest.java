package com.ssafy.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.service.BoardService;

public class DITest {

	public static void main(String[] args) {
		BeanFactory con = new ClassPathXmlApplicationContext("com/ssafy/config/beans1.xml");
		BoardService bservice = con.getBean(BoardService.class);
		System.out.println(bservice.search("1"));
	}
}
