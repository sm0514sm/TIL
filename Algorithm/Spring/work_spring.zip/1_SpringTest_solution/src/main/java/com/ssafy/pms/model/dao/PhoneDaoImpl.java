package com.ssafy.pms.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.pms.Phone;
import com.ssafy.pms.UserInfo;

@Repository
public class PhoneDaoImpl implements PhoneDao {
	@Autowired
	private SqlSession session;
	private String ns = "sql.pms.";

	@Override
	public void insert(Phone phone) {
		session.insert(ns + "insert", phone);
	}

	@Override
	public void delete(List<String> num) {
//		for (String string : num) {
//			session.delete(ns+"delete", string);
//		}
//		위랑 아래랑 같은 작업
		session.delete(ns + "delete2", num);
	}

	@Override
	public Phone search(String num) {
		return session.selectOne(ns + "search", num);
	}

	@Override
	public List<Phone> searchAll() {
		return session.selectList(ns + "searchAll");
	}

	@Override
	public UserInfo findUser(String id) {
		return session.selectOne(ns + "findUser", id);
	}

}
