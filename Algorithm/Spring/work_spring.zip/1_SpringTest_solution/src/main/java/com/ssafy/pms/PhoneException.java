package com.ssafy.pms;

public class PhoneException extends RuntimeException {
	public PhoneException() {
	}

	public PhoneException(String message) {
		super(message);
	}
}
