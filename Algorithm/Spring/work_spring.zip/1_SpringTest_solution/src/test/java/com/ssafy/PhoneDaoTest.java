package com.ssafy;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.ssafy.pms.Phone;
import com.ssafy.pms.model.dao.PhoneDao;

// 단위 테스트를 동작시킬 대상을 지정
@RunWith(SpringRunner.class)	// SpringRunner는 Spring 컨테이너를 동작시킬 클래스
// Spring을 위한 bean configuration 설정
@ContextConfiguration("classpath:/spring/application-config.xml")
public class PhoneDaoTest {
	@Autowired
	PhoneDao dao;

	@Test	// 단위 테스트를 위한 대상 지정	
	public void testBean() {
		/*
		 * assertThat(actual, matcher)
		 * 단위 테스트한 결과를 확인하기 위한 메서드
		 * actual : 결과
		 * matcher : 확인	=>	원하는 값이 아니면 fail이 되고 해당 메세지가 출력됨
		 */
		assertThat(dao, is(notNullValue()));
	}
	
	@Test
	public void insertPhone() {
		Phone p = new Phone("s123", "galaxy s9+", 10000, "10");
		dao.insert(p);
		
		Phone find = dao.search("s123");
		assertThat(find, is(notNullValue()));
	}
	
	@Test
	public void deletePhone() {
		List<String> list = Arrays.asList("s123");
		dao.delete(list);
		Phone find = dao.search("s123");
		assertThat(find, is(nullValue()));
	}
}
