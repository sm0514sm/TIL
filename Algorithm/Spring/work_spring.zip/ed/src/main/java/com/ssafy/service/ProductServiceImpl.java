package com.ssafy.service;

import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;
import com.ssafy.model.repository.ProductRepoImpl;

public class ProductServiceImpl implements ProductService {
	private ProductRepo repo = null;
	
	public ProductServiceImpl() {
		this.repo = getRepo();
	}

	@Override
	public ProductRepo getRepo() {
		return new ProductRepoImpl();
	}

	@Override
	public List<Product> selectAll() {
		try {
			return repo.selectAll();
		} catch (Exception e) {
			e.printStackTrace();
			//
		}
		return null;
	}

	@Override
	public Product select(String id) {
		try {
			return repo.select(id);
		} catch (Exception e) {
			e.printStackTrace();
//			
		}
		return null;
	}

	@Override
	public int insert(Product product) {
		try {
			repo.insert(product);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int update(Product product) {
		try {
			repo.update(product);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delete(String id) {
		try {
			repo.delete(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

}
