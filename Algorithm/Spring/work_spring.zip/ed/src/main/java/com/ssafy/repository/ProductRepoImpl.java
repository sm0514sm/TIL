package com.ssafy.repository;

import java.util.List;

import com.ssafy.dto.Product;

public class ProductRepoImpl implements ProductRepo {

	@Override
	public List<Product> selectAll() {
		return null;
	}

	@Override
	public Product select(String id) {
		return null;
	}

	@Override
	public int insert(Product product) {
		return 0;
	}

	@Override
	public int update(Product product) {
		return 0;
	}

	@Override
	public int delete(String id) {
		return 0;
	}

}
