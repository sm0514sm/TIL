package com.ssafy.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.config.MyBatis;
import com.ssafy.dto.Product;

public class ProductDaoImpl implements ProductDao {
	private SqlSession session = MyBatis.getSqlSession();
	
	@Override
	public void insert(Product product) {
		session.insert("product.insert", product);
		session.commit();
	}
	
	@Override
	public void delete(String id) {
		session.delete("product.delete", id);
		session.commit();
	}
	
	@Override
	public void update(Product product) {
		session.update("product.update", product);
		session.commit();
	}
	
	
	@Override
	public List<Product> selectAll() {
		return session.selectList("product.selectAll");
	}

	@Override
	public Product select(String id) {
		return session.selectOne("product.select", id);
	}
}
