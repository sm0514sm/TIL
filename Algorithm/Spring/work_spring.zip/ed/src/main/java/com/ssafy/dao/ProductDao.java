package com.ssafy.dao;

import java.util.List;

import com.ssafy.dto.Product;

public interface ProductDao {
	public void insert(Product product);
	public void delete(String id);
	public void update(Product product);
	public List<Product> selectAll();
	public Product select(String id);
}
	