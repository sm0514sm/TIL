package com.ssafy.pms.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.pms.Phone;
import com.ssafy.pms.UserInfo;

@Mapper	// query.xml을 자동 매핑
public interface PhoneDao {
	public void 		insert(Phone phone);
	public void 		delete(List<String> num);
	public Phone 		search(String num);
	public List<Phone> 	searchAll();
	public UserInfo 	findUser(String id);
}
