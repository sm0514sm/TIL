package com.ssafy.model.dto;

import java.io.Serializable;
import java.util.List;

public class Department implements Serializable{
	private int dept_id;
	private String name;
	private int region_id;
	private List<Employee> employees;
	
	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public Department(int dept_id, String name, int region_id) {
		this.dept_id = dept_id;
		this.name = name;
		this.region_id = region_id;
	}
	
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRegion_id() {
		return region_id;
	}
	public void setRegion_id(int region_id) {
		this.region_id = region_id;
	}
	
}
