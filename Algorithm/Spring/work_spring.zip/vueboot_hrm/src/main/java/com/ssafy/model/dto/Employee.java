package com.ssafy.model.dto;

import java.io.Serializable;

public class Employee implements Serializable{
	private int id;
	private String name;
	private String mailid;
	private String start_date;
	private Integer manager_id;
	private String title;
	private int dept_id; 
	private Double salary; 
	private Double commission_pct;
	
	public Employee(int id, String name, String mailid, String start_date, Integer manager_id, String title, int dept_id,
			Double salary, Double commission_pct) {
		this.id = id;
		this.name = name;
		this.mailid = mailid;
		this.start_date = start_date;
		this.manager_id = manager_id;
		this.title = title;
		this.dept_id = dept_id;
		this.salary = salary;
		this.commission_pct = commission_pct;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public int getManager_id() {
		if(manager_id == null)
			manager_id = 0;
		return manager_id;
	}
	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public double getSalary() {
		if(salary == null)
			salary = (double) 0;
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public double getCommission_pct() {
		if(commission_pct == null)
			commission_pct = (double) 0;
		return commission_pct;
	}
	public void setCommission_pct(double commission_pct) {
		this.commission_pct = commission_pct;
	}
	
	
}
