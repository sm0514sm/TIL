package com.ssafy.service;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.model.dto.Department;
import com.ssafy.model.dto.Employee;

public interface EmployeeService {
	public int addEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	public List<String> findAllDepartments();
	public List<Employee> findAllEmployees();
	public List<String> findAllTitles();
	public Employee findEmployeeById(int id);
	public List<Employee> findLikeEmployees(String name);
	public int getEmployeesTotal();
	public void updateEmployee(Employee employee);
	
	public Department selectDeptByIdWithEmployees(int id) throws Exception;
}
