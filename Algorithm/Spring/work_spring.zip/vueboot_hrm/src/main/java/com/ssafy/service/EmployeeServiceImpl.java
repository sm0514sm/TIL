package com.ssafy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dao.EmployeeDAO;
import com.ssafy.model.dto.Department;
import com.ssafy.model.dto.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDAO dao;
	
	
	@Override
	public int addEmployee(Employee employee) {
		try {
			dao.addEmployee(employee);
			return employee.getId();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("addEmployee 중 오류 발생");
		}
	}

	@Override
	public void deleteEmployee(int employeeId) {
		try {
			dao.deleteEmployee(employeeId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("deleteEmployee 중 오류 발생");
		}
	}

	@Override
	public List<String> findAllDepartments() {
		try {
			return dao.findAllDepartments();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("findAllDepartments 중 오류 발생");
		}
	}

	@Override
	public List<Employee> findAllEmployees() {
		try {
			return dao.findAllEmployees();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("findAllEmployees 중 오류 발생");
		}
	}

	@Override
	public List<String> findAllTitles() {
		try {
			return dao.findAllTitles();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("findAllTitles 중 오류 발생");
		}
	}

	@Override
	public Employee findEmployeeById(int id) {
		try {
			return dao.findEmployeeById(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("findEmployeeById 중 오류 발생");
		}
	}

	@Override
	public List<Employee> findLikeEmployees(String name) {
		try {
			return dao.findLikeEmployees(name);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("findLikeEmployees 중 오류 발생");
		}
	}

	@Override
	public int getEmployeesTotal() {
		try {
			return dao.getEmployeesTotal();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("getEmployeesTotal 중 오류 발생");
		}
	}

	@Override
	public void updateEmployee(Employee employee) {
		try {
			dao.updateEmployee(employee);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("updateEmployee 중 오류 발생");
		}
	}

	@Override
	public Department selectDeptByIdWithEmployees(int id) throws Exception {
		return dao.selectDeptByIdWithEmployees(id);
	}

}
