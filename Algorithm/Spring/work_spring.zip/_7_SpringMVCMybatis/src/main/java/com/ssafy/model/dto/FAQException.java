package com.ssafy.model.dto;

public class FAQException extends RuntimeException {
	
	public FAQException() {
	}

	public FAQException(String msg) {
		super(msg);
	}
}
