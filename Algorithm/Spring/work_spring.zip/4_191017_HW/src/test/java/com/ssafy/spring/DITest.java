package com.ssafy.spring;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.domain.Product;
import com.ssafy.model.service.ProductService;

public class DITest {

	public static void main(String[] args) {
		BeanFactory con = new ClassPathXmlApplicationContext("com/ssafy/config/beans2.xml");
		ProductService pservice = con.getBean(ProductService.class);
		System.out.println(pservice.selectAll());
		
		Product product1 = new Product("1111", "킹왕짱상민", 2310000, "왕");
		Product product2 = new Product("2222", "킹상민", 1000000, "킹");
		Product product3 = new Product("3333", "오예 예예", 12141200, "개빠름");
		
		System.out.println("\n*------------전체 목록 출력---------------*");
		List<Product> products = pservice.selectAll();
		for (Product product: products)
			System.out.println(product);
		
		System.out.println("\n*------------1111 찾기 출력---------------*");
		System.out.println(pservice.select("1111"));
		
		System.out.println("\n*------------1111, 2222 삭제---------------*");
		pservice.delete("1111");
		pservice.delete("2222");
		
		System.out.println("\n*------------전체 목록 출력---------------*");
		products = pservice.selectAll();
		for (Product product: products) 
			System.out.println(product);
		
		System.out.println("\n*------------3333 삭제---------------*");
		pservice.delete("3333");
		
		System.out.println("\n*------------전체 목록 출력---------------*");
		products = pservice.selectAll();
		for (Product product: products) 
			System.out.println(product);
		
		System.out.println("\n*------------1111, 2222, 3333 추가---------------*");
		pservice.insert(product1);
		pservice.insert(product2);
		pservice.insert(product3);
		
		System.out.println("\n*------------전체 목록 출력---------------*");
		products = pservice.selectAll();
		for (Product product: products) 
			System.out.println(product);
	}
}
