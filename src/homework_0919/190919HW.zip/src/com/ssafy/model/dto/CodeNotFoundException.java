package com.ssafy.model.dto;

public class CodeNotFoundException extends Exception {

	public CodeNotFoundException() {
		super("상품 번호가 존재하지 않아요!");
	}

}
