import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ItemAddServlet
 */
@WebServlet("/add.do")
public class ItemAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static int count = 1;
    public ItemAddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		request.setAttribute("name", request.getParameter("name"));
//		request.setAttribute("price", request.getParameter("price"));
//		request.setAttribute("text", request.getParameter("text"));
		request.setAttribute("no", count++);
		request.getRequestDispatcher("saved.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
