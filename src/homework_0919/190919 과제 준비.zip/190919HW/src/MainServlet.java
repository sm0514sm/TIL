import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {

    public MainServlet() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		String ID = request.getParameter("id");
		String PW = request.getParameter("password");
		System.out.println(ID);
		System.out.println(PW);
		if(ID.equals("ssafy") && PW.equals("1111"))
			response.sendRedirect("Result.html");
		else 
			response.sendRedirect("Login.html");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		request.setCharacterEncoding("utf-8"); //post 만 유효.
		String[] isbn = new String[4];
		for(int i=1; i<=3; i++) {
			isbn[i-1] = request.getParameter("isbn"+i);
		}
		String title = request.getParameter("title");
		String catalogue = request.getParameter("catalogue");
		String nation = request.getParameter("nation");
		String publisheDate = request.getParameter("publisheDate");
		String publisher = request.getParameter("publisher");
		String author = request.getParameter("author");
		String price = request.getParameter("price");
		String description = request.getParameter("description");

		out.println("<html>");
		out.println("<body>");
		out.println("<h1>");
		out.println("입력된 도서 정보");
		out.println("</h1>");
		out.println("<table border='1'>");
		out.println("<colgroup> "
		+ "<col style='background: grey' /> "
		+ "</colgroup>");
		out.println("<thead style='background: grey'>");
		out.println("<td colspan='2'> 도서정보 </td> </thead>");
		out.println("<tr>");
		out.println("<td> 도서명 </td> <td>"+title+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 도서번호 </td> <td>"+isbn[0]+"-"+isbn[1]+"-"+isbn[2]+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 도서 분류 </td> <td>"+catalogue+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 도서 국가 </td> <td>"+nation+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 출판일 </td> <td>"+publisheDate+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 출판사 </td> <td>"+publisher+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 저자 </td> <td>"+author+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 도서가격 </td> <td>"+price+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td> 도서 설명 </td> <td>"+description+"</td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("<a href=\"./book.html\"> 도서 등록</a>");
		out.println("</body>");
		out.println("</html>");

		out.close();
		}


}
