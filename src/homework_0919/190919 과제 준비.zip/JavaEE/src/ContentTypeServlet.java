

import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/content")
public class ContentTypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("HelloServlet doGet...");
		response.setContentType("image/png;charset=utf-8");	//항상 먼저 설정하자!
		FileInputStream fis = null;
		ServletOutputStream out = null;
		System.out.println("실행됨");
		try {
			fis = new FileInputStream("C:/SSAFY/logo.png");
			out = response.getOutputStream();
			byte[] buf = new byte[1024];
			int len = 0;
			while((len = fis.read(buf)) != -1){
				out.write(buf, 0, len);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			fis.close();
			out.close();
		}
	}
}
