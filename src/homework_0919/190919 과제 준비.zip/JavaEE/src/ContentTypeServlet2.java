

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/content2")
public class ContentTypeServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("HelloServlet doGet...");
		response.setContentType("text/html;charset=utf-8");	//항상 먼저 설정하자!
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<h1 style='color:pink'>");
		out.println("Hello SSAFYYYYYY");
		out.println(new Date());
		out.println("</h1>");
		out.println("</body>");
		out.println("</html>");
	}
}
