package com.ssafy.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.domain.Product;
import com.ssafy.model.dto.Member;
import com.ssafy.model.service.MemberService;
import com.ssafy.model.service.MemberServiceImp;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImp;

@WebServlet("*.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService = new MemberServiceImp();
	private ProductService productService = new ProductServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "index.jsp";
		String action = request.getServletPath();
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		System.out.println("action : " + action);
		try {
			if(action != null) {
					 if (action.endsWith("Login.do"))			url = login(request, response);
				else if (action.endsWith("Logout.do"))			url = logout(request, response);
				else if (action.endsWith("LoginForm.do"))		url = "Login.jsp";
				else if (action.endsWith("AddItemForm.do"))		url = "AddItem.html";
				/*	TODO
				 *  1. mySQL Product 테이블 만들기
				 *  2. ProductDAOImp를 mySQL에 연동해서 구현하기
				 *  3. ProductService와 ProductServiceImp 구현하기
				 *  4. MainServlet에 ProductServiceImp객체 글로벌 멤버로 선언하기
				 ///*----------------------- 구현의 선 -------------------------------
				 *  5. ProductServiceImp객체를 이용해서 addItem, viewItemList, editItem, deleteItem
				 *  6. addItem 할 때 cookie 만들기
				 *  7. LastAddedItem.jsp 만들기
				 *  8. LastAddedItem.jsp에 쿠키가져와서 표시하기
				 */
				else if (action.endsWith("AddItem.do"))			url = addItem(request, response);
				else if (action.endsWith("ItemList.do"))		url = viewItemList(request, response);
				else if (action.endsWith("LastAddedItem.do"))	url = "lastAddedItem.jsp";
				else if (action.endsWith("EditItem.do"))		url = editItem(request, response);
				else if (action.endsWith("DeleteItem.do"))		url = deleteItem(request, response);
//					 if (action.endsWith("memberRegistForm.do"))	url = "member/memberRegister.html";
//				else if (action.endsWith("memberRegit.do")) 		url = memberRegit(request, response);
//				else if (action.endsWith("memberSearch.do"))		url = memberSearch(request, response);
//				else if (action.endsWith("cookietest.do"))			url = cookietest(request, response);
//				else if (action.endsWith("cookielogin.do"))			url = cookielogin(request, response);
//				else if (action.endsWith("login.do"))				url = login(request, response);
//				else if (action.endsWith("logout.do"))				url = logout(request, response);
//				else if (action.endsWith("goodsList.do"))			url = "cart1/book.html";
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", e.getMessage());
			url = "ErrorHandler.jsp";
		}
		if(url.startsWith("redirect")) {
			response.sendRedirect(url.substring(url.indexOf(":")+1));
		}else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
	
	private String login(HttpServletRequest request, HttpServletResponse response) {
		String idSave = request.getParameter("idsave");
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		
		Cookie cookie = new Cookie("id", id);
		if(idSave != null) { //checked 박스가 선택된 상황 => cookie를 통해 id 유지
			cookie.setMaxAge(100000000);
		}else {	//checked 박스가 선택되지 않은 상황 => cookie 삭제
			cookie.setMaxAge(0);
		}
		response.addCookie(cookie);
		
		try {
			memberService.login(id, password);			
			HttpSession session = request.getSession();
			//session에 인증 정보를 저장 ex) `아이디`, 권한정보, 닉네임
			session.setAttribute("id", id);		// session에 id가 있으면 로그인 한 것
			return "redirect:Login.do"; 
		} catch (Exception e) {
			request.setAttribute("msg", e.getMessage());
			return "Login.jsp";
		}
	}
	
	private String logout(HttpServletRequest request, HttpServletResponse response) {
		/*로그아웃
		 * 	1. invalidate()
		 * 		- session에 인증 정보만 있을 때
		 * 	2. 인증정보 제거
		 * 		- session에 인증 정보 외에 다른 정보가 저장된 경우(장바구니, 최근 본 상품,...)
		 */
		HttpSession session = request.getSession();
		session.removeAttribute("id"); //	인증정보 제거
		return "redirect:LoginForm.do";
	}
	
	private String addItem(HttpServletRequest request, HttpServletResponse response) {
		String no = request.getParameter("no");
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		String text = request.getParameter("text");
		Product product = new Product(no, name, price, text);
		
		productService.add(product);
		request.setAttribute("product", product);
		
		Cookie cookie = new Cookie("lastProduct", no);
		response.addCookie(cookie);
		return "LastAddedItem.do"; 
	}

	private String viewItemList(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		String searchType = (String)request.getParameter("searchType");
		String searchName = (String) request.getParameter("searchName");
		String searchPrice = (String) request.getParameter("searchPrice");
		int searchTypeNum;
		if(searchType != null) {
			searchTypeNum = Integer.parseInt(searchType);
			if(searchTypeNum == 0) session.setAttribute("products", productService.searchAll(searchName));
			if(searchTypeNum == 1) session.setAttribute("products", productService.searchAll(Integer.parseInt(searchPrice)));
		}
		else{session.setAttribute("products", productService.searchAll());
			request.setAttribute("msg", "검색 조건을 설정해서 검색해주세요!");
		}
		return "itemList.jsp";
	}

	private String viewLastItem(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

	private String editItem(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

	private String deleteItem(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

	private String memberRegit(HttpServletRequest request, HttpServletResponse response) {
//		1. 요청정보
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		Member member = new Member(id, pw, name, email, phone, address);
		memberService.add(member);
		
		return "redirect:memeberSearch.do?id="+id;
	}
	
	private String memberSearch(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		request.setAttribute("member", memberService.search(id));
		return "member/memberSearch.jsp";
	}
	
	private String cookietest(HttpServletRequest request, HttpServletResponse response) {
		String cookieName = request.getParameter("cookiename");
		String cookieValue = request.getParameter("cookievalue");
		Cookie cookie = new Cookie(cookieName, cookieValue);
		//쿠키 유효기간 설정
		cookie.setMaxAge(0);
		//쿠키 발생
		response.addCookie(cookie);
		return "CookieTest.jsp";
	}
	
	private String cookielogin(HttpServletRequest request, HttpServletResponse response) {
		String idSave = request.getParameter("idsave");
		String id = request.getParameter("id");
		
		Cookie cookie = new Cookie("id", id);
		if(idSave != null) { //checked 박스가 선택된 상황 => cookie를 통해 id 유지
			cookie.setMaxAge(100000000);
		}else {	//checked 박스가 선택되지 않은 상황 => cookie 삭제
			cookie.setMaxAge(0);
		}
		response.addCookie(cookie);
		
		return "redirect:CookieLogin.jsp";
	}
}











