package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.ssafy.model.domain.Product;
import com.ssafy.util.DBUtil;

public class ProductDAOImp implements ProductDAO {
	public Product search(String no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from product where no = ? ";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, no);
			rs = stmt.executeQuery();
			if(rs.next()) {
				return new Product(rs.getString("no"), rs.getString("name"), rs.getInt("price"), rs.getString("text"));
			}
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
		return null;
	}

	public List<Product> searchAll() throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from product  ";
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			List<Product> products = new LinkedList<Product>();
			while(rs.next()) {
				products.add(new Product(rs.getString("no"), rs.getString("name"), rs.getInt("price"), rs.getString("text")));
			}
			return products;
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
	}
	
	public List<Product> searchAll(String searchName) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from product where name like concat('%',?,'%') ";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, searchName);	
			rs = stmt.executeQuery();
			List<Product> products = new LinkedList<Product>();
			while(rs.next()) {
				products.add(new Product(rs.getString("no"), rs.getString("name"), rs.getInt("price"), rs.getString("text")));
			}
			return products;
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
	}

	public List<Product> searchAll(int parseInt) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from product where price <= ? ";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, parseInt);	
			rs = stmt.executeQuery();
			List<Product> products = new LinkedList<Product>();
			while(rs.next()) {
				products.add(new Product(rs.getString("no"), rs.getString("name"), rs.getInt("price"), rs.getString("text")));
			}
			return products;
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
	}
	
	public void add(Product product) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " insert into product(no,name,price,text) "
					   + " values(?,?,?,?) ";
			stmt = con.prepareStatement(sql);
			int nox = 1;
			stmt.setString(nox++, product.getNo());		
			stmt.setString(nox++, product.getName());		
			stmt.setInt(nox++, product.getPrice());		
			stmt.setString(nox++, product.getText());
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	public void update(Product product) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " update product set name=?, price=?, text=? where no=? " ;
			
			stmt = con.prepareStatement(sql);
			int nox = 1;
			stmt.setString(nox++, product.getName());		
			stmt.setInt(nox++, product.getPrice());		
			stmt.setString(nox++, product.getText());
			stmt.setString(nox++, product.getNo());		
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	public void remove(String no) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " delete from product where no=? " ;
			stmt = con.prepareStatement(sql);
			stmt.setString(1, no);		
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

}







