package com.ssafy.model.service;

import java.util.List;

import com.ssafy.model.domain.Product;

public interface ProductService {
	public Product search(String id);
	public List<Product> searchAll();
	public List<Product> searchAll(int parseInt);
	public List<Product> searchAll(String searchName);
	public void add(Product product);
	public void update(Product product);
	public void remove(String id);
}
