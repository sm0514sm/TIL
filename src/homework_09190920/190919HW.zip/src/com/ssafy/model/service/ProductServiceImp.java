package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dao.ProductDAO;
import com.ssafy.model.dao.ProductDAOImp;
import com.ssafy.model.domain.Product;
import com.ssafy.model.dto.MemberException;

public class ProductServiceImp implements ProductService {
	private ProductDAO dao = new ProductDAOImp();
	public Product search(String no) {
		try {
			Product product = dao.search(no);
			if(product == null) {
				throw new MemberException("등록되지 않은 아이디입니다.");
			}else {
			   return product;
			}
		} catch (Exception e) {
			throw new MemberException();
		}
	}

	public List<Product> searchAll() {
		try {
			return dao.searchAll();
		}catch (SQLException e) {
			throw new MemberException();
		}
	}
	public List<Product> searchAll(int parseInt) {
		try {
			return dao.searchAll(parseInt);
		} catch (SQLException e) {
			throw new MemberException();
		}
	}

	public List<Product> searchAll(String searchName) {
		try {
			return dao.searchAll(searchName);
		} catch (SQLException e) {
			throw new MemberException();
		}
	}
	public void add(Product product) {
		try {
			Product find = dao.search(product.getNo());
			if(find != null) {
				throw new MemberException("이미 등록된 제품입니다.");
			}else {
				dao.add(product);
			}
		} catch (SQLException e) {
			throw new MemberException();
		}
	}
	public void update(Product product) {
		try {
			Product find = dao.search(product.getNo());
			if(find == null) {
				throw new MemberException("수정할 제품 정보가 없습니다.");
			}else {
				dao.update(product);
			}
		} catch (SQLException e) {
			throw new MemberException();
		}
	}

	public void remove(String no) {
		try {
			Product find = dao.search(no);
			if(find == null) {
				throw new MemberException("제거할 제품 정보가 없습니다.");
			}else {
				dao.remove(no);
			}
		} catch (SQLException e) {
			throw new MemberException();
		}
	}

}
