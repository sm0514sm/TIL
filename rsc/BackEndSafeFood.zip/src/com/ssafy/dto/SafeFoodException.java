package com.ssafy.dto;

public class SafeFoodException extends RuntimeException {
	public SafeFoodException(String msg) {
		super(msg);
	}
}
