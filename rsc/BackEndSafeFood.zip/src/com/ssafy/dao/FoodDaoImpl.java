package com.ssafy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.ssafy.dto.Food;
import com.ssafy.dto.FoodPageBean;
import com.ssafy.util.DBUtil;
import com.ssafy.util.FoodSaxParser;

public class FoodDaoImpl implements FoodDao{

	public FoodDaoImpl() {
		//loadData();
	}
	/**
	 * 식품 영양학 정보와 식품 정보를  xml 파일에서 읽어온다.
	 */
	public void loadData() {
		
		//  FoodNutritionSaxPaser를 이용하여 Food 데이터들을 가져온다
		try {
			FoodSaxParser fp = new FoodSaxParser();
			List<Food> mapList = fp.getFoods();
			//  가져온 Food 리스트 데이터를 DB에 저장한다.
			for(Food food: mapList) {
				Connection con = null;
				PreparedStatement stmt = null;
				try {
					con = DBUtil.getConnection();
					String sql = " insert into food(code, name, supportpereat, calory, carbo "
							+ " ,protein, fat, sugar, natrium, chole, fattyacid, transfat "
							+ " , maker, material, img, allergy)"
							+ " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
					stmt = (PreparedStatement) con.prepareStatement(sql);
					int idx = 1;
					stmt.setInt(idx++, food.getCode());
					stmt.setString(idx++, food.getName());
					stmt.setDouble(idx++, food.getSupportpereat());
					stmt.setDouble(idx++, food.getCalory());
					stmt.setDouble(idx++, food.getCarbo());
					stmt.setDouble(idx++, food.getProtein());
					stmt.setDouble(idx++, food.getFat());
					stmt.setDouble(idx++, food.getSugar());
					stmt.setDouble(idx++, food.getNatrium());
					stmt.setDouble(idx++, food.getChole());
					stmt.setDouble(idx++, food.getFattyacid());
					stmt.setDouble(idx++, food.getTransfat());
					stmt.setString(idx++, food.getMaker());
					stmt.setString(idx++, food.getMaterial());
					stmt.setString(idx++, food.getImg());
					stmt.setString(idx++, food.getAllergy());
					stmt.executeUpdate();
					
				} catch (SQLException e) {
					
				}finally {
					DBUtil.close(stmt);
					DBUtil.close(con);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
				
	}
	
	
	/**
	 * 검색 조건(key) 검색 단어(word)에 해당하는 식품 정보(Food)의 개수를 반환. 
	 * web에서 구현할 내용. 
	 * web에서 페이징 처리시 필요 
	 * @param bean  검색 조건과 검색 단어가 있는 객체
	 * @return 조회한  식품 개수
	 */
	public int foodCount(FoodPageBean  bean){
		return searchAll().size();
	}
	
	public List<Food> searchAll() {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from product  ";
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			List<Food> products = new LinkedList<Food>();
			while(rs.next()) {
				products.add(new Food(rs.getInt("code"), rs.getString("name"), rs.getDouble("supportpereat"), rs.getDouble("calory"), rs.getDouble("carbo"), rs.getDouble("protein"), rs.getDouble("fat"), rs.getDouble("sugar"), rs.getDouble("natrium"), rs.getDouble("chole"), rs.getDouble("fattyacid"), rs.getDouble("transfat"), rs.getString("maker"), rs.getString("material"), rs.getString("img"), rs.getString("allergy")));
			}
			return products;
		} catch (Exception e) {
		}finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
		return null;
	}
	
	public List<Food> searchAll(String str, int type) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from product  ";
			switch (type) {
			case 1: // 
				sql += "";
				break;
			case 2:
				sql += "";
				break;
			case 3:
				sql += "";
				break;
			case 4:
				sql += "";
				break;
			default:
				System.out.println("알수없는 에러 발생!!!!!!!!!!");
				break;
			}
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			List<Food> products = new LinkedList<Food>();
			while(rs.next()) {
				products.add(new Food(rs.getInt("code"), rs.getString("name"), rs.getDouble("supportpereat"), rs.getDouble("calory"), rs.getDouble("carbo"), rs.getDouble("protein"), rs.getDouble("fat"), rs.getDouble("sugar"), rs.getDouble("natrium"), rs.getDouble("chole"), rs.getDouble("fattyacid"), rs.getDouble("transfat"), rs.getString("maker"), rs.getString("material"), rs.getString("img"), rs.getString("allergy")));
			}
			return products;
		} catch (Exception e) {
		}finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
		return null;
	}
	
	public Food search(int code) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from food where code  = ? ";
			stmt = (PreparedStatement) con.prepareStatement(sql);
			stmt.setInt(1, code);
			rs = stmt.executeQuery();
			if(rs.next()) {
				return new Food(rs.getInt("code"), rs.getString("name"), rs.getDouble("supportpereat"),
						rs.getDouble("calory"), rs.getDouble("carbo"), rs.getDouble("protein"), rs.getDouble("fat"),
						rs.getDouble("sugar"), rs.getDouble("natrium"), rs.getDouble("chole"),
						rs.getDouble("fattyacid"), rs.getDouble("transfat"), rs.getString("maker"),
						rs.getString("material"), rs.getString("img"), rs.getString("allergy"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return null;
	}

	/**
	 * 가장 많이 검색한 Food  정보 리턴하기 
	 * web에서 구현할 내용.  
	 * @return
	 */
	public List<Food> searchBest() {
		return null;
	}
	
	public List<Food> searchBestIndex() {
		return null;
	}
	
}
