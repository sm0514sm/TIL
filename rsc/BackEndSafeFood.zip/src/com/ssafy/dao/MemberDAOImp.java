package com.ssafy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.ssafy.dto.Member;
import com.ssafy.util.DBUtil;

public class MemberDAOImp implements MemberDAO {
	public Member search(String id) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from members where id = ? ";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, id);
			rs = stmt.executeQuery();
			if(rs.next()) {
				return new Member(rs.getString("id")
						        , rs.getString("password")
						        , rs.getString("name")
						        , rs.getString("phone")
						        , rs.getString("address")
						        , rs.getString("allergy")
						        );
			}
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
		return null;
	}

	public List<Member> searchAll() throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from members  ";
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			List<Member> members = new LinkedList<Member>();
			while(rs.next()) {
				members.add(new Member(rs.getString("id")
						        , rs.getString("name")
						        , rs.getString("phone")
						        , rs.getString("address")
						        , rs.getString("allergy")));
			}
			return members;
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
	}
	public void add(Member member) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " insert into members(id,password,name,phone,address,allergy) "
					   + " values(?,?,?,?,?,?) ";
			stmt = con.prepareStatement(sql);
			int idx = 1;
			stmt.setString(idx++, member.getId());		
			stmt.setString(idx++, member.getPassword());		
			stmt.setString(idx++, member.getName());		
			stmt.setString(idx++, member.getPhone());		
			stmt.setString(idx++, member.getAddress());
			stmt.setString(idx++, member.getAllergy());
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	public void update(Member member) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " update members set password=?, name=?, phone=? "
						+"                  , address=? , allergy=? where id=? " ;
			
			stmt = con.prepareStatement(sql);
			int idx = 1;
			stmt.setString(idx++, member.getPassword());		
			stmt.setString(idx++, member.getName());			
			stmt.setString(idx++, member.getPhone());		
			stmt.setString(idx++, member.getAddress());
			stmt.setString(idx++, member.getAllergy());
			stmt.setString(idx++, member.getId());		
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
	public void remove(String id) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " delete from members where id=? " ;
			stmt = con.prepareStatement(sql);
			stmt.setString(1, id);		
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}
}







