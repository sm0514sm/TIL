package com.ssafy.dao;

import java.util.List;

import com.ssafy.dto.Food;
import com.ssafy.dto.FoodPageBean;

public interface FoodDao {
	public void loadData();
	public int foodCount(FoodPageBean bean);
	public List<Food> searchAll();
	public List<Food> searchAll(String str, int type);	//name or maker
	public Food search(int code);
	public List<Food> searchBest();
	public List<Food> searchBestIndex();
}
