package com.ssafy.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.dto.Member;
import com.ssafy.service.FoodService;
import com.ssafy.service.FoodServiceImpl;
import com.ssafy.service.MemberService;
import com.ssafy.service.MemberServiceImp;

@WebServlet("*.do")
public class MainServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService = new MemberServiceImp();
	private FoodService foodService = new FoodServiceImpl();
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "index.jsp";
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String action = request.getServletPath();
		System.out.println("action............"+action);
		try {
			if (action != null) {
					 //if (action.endsWith("ItemList.do"))	url = viewItemList(request, response);
				//else 
					if (action.endsWith("memberregister.do"))	url = memberregister(request, response);
//				else if (action.endsWith("ItemList.do"))	url = viewItemList(request, response);
//				else if (action.endsWith("ItemList.do"))	url = viewItemList(request, response);
//				else if (action.endsWith("ItemList.do"))	url = viewItemList(request, response);
//				else if (action.endsWith("ItemList.do"))	url = viewItemList(request, response);
//				else if (action.endsWith("ItemList.do"))	url = viewItemList(request, response);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", e.getMessage());
			url = "ErrorHandler.jsp";
		}
		
		if(url.startsWith("{") ||url.startsWith("[") ) {
			// json으로 인식 -- 바로 출력
			// url이 { or [ 로 시작하면 JSON 데이터이므로
			// contents타입 변경후 직접 출력
			response.setContentType("application/json;charset=utf-8");
			response.getWriter().append(url);
		}else if(url.startsWith("redirect")) {
			response.sendRedirect(url.substring(url.indexOf(":")+1));
		}else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
	private String memberregister(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String[] allergy = request.getParameterValues("allergy");
		String al = "";
		for(int i=0; i<allergy.length; i++) {
			if(i==0) {
				al += allergy[i];
			}else {
				al += ","+allergy[i];
			}
		}
		
		if(!memberService.checkID(id)) {
			try {
				// false -- 가입할 수 있음
				memberService.add(new Member(id, password, name, phone, address, al));
//				Cookie cookie = new Cookie(id, "id");
//				response.addCookie(cookie);
				request.setAttribute("id", id);
				System.out.println(id);
				return "index.jsp";
			} catch (Exception e) {
				System.out.println(e);
				request.setAttribute("msg", e.getMessage());
			}
		}		
		else {
			String msg = "이미존재하는 회원입니다";
			request.setAttribute("msg", msg);
		
		}
	
		return "register.jsp";
	}
//	private String viewItemList(HttpServletRequest request, HttpServletResponse response) {
//		HttpSession session = request.getSession();
//		String searchType = (String) request.getParameter("searchType");
//		String searchName = (String) request.getParameter("searchName");
//		String searchPrice = (String) request.getParameter("searchPrice");
//		int searchTypeNum;
//		if (searchType != null) {
//			searchTypeNum = Integer.parseInt(searchType);
//			if (searchTypeNum == 0)
//				session.setAttribute("products", foodService.searchAll(searchName));
//			if (searchTypeNum == 1)
//				session.setAttribute("products", foodService.searchAll(Integer.parseInt(searchPrice)));
//		} else {
//			session.setAttribute("products", productService.searchAll());
//			request.setAttribute("msg", "검색 조건을 설정해서 검색해주세요!");
//		}
//		return "itemList.jsp";
//	}

}
