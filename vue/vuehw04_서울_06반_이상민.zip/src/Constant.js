export default {
  GET_TODOLIST: "getTodoList",
  GET_TODO: "getTodo",
  ADD_TODO: "addTodo",
  MODIFY_TODO: "modifyTodo",
  REMOVE_TODO: "removeTodo",
  COMPLETE_TODO: "completeTodo",
  CLEAR_TODO: "clearTodo"
};
