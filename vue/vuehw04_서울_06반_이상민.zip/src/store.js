import Vue from "vue";
import Vuex from "vuex";
import Constant from "./Constant";
import http from "./http-common";
Vue.use(Vuex);
const store = new Vuex.Store({
  state: {
    todoItems: [],
    todo: {}
  },
  actions: {
    [Constant.GET_TODO]: (store, payload) => {
      http
        .get("/todolist/todo/" + payload.no)
        .then(response => {
          store.commit(Constant.GET_TODO, { todo: response.data });
        })
        .catch(exp => alert("처리에 실패하였습니다." + exp));
    },
    [Constant.GET_TODOLIST]: store => {
      http
        .get("/todolist/user/java")
        .then(response => {
          console.log("asdf");
          store.commit(Constant.GET_TODOLIST, { todoItems: response.data });
          console.log(response.data);
        })
        .catch(exp => alert("처리에 실패하였습니다." + exp));
    },
    [Constant.REMOVE_TODO]: (store, payload) => {
      http
        .delete("todolist/todo/" + payload.no)
        .then(() => {
          console.log("삭제 처리 되었습니다.");
          store.dispatch(Constant.GET_TODOLIST);
        })
        .catch(exp => alert("삭제 처리에 실패하였습니다" + exp));
    },
    [Constant.COMPLETE_TODO]: (store, payload) => {
      http
        .put("todolist/todo/done/" + payload.no)
        .then(() => {
          store.dispatch(Constant.GET_TODOLIST);
          console.log("완료 처리 되었습니다.");
        })
        .catch(exp => alert("완료 처리에 실패하였습니다" + exp));
    },
    [Constant.ADD_TODO]: (store, payload) => {
      http
        .post("/todolist/todo", {
          content: payload.todo.content,
          endDate: payload.todo.endDate,
          userId: "java"
        })
        .then(() => {
          console.log("추가하였습니다.");
          store.dispatch(Constant.GET_TODOLIST);
        })
        .catch(() => console.log("추가에 실패하였습니다."));
    }
  },
  mutations: {
    // 저장소에 데이터 실제 반영(commit시 호출)
    [Constant.GET_TODOLIST]: (state, payload) => {
      store.state.todoItems = payload.todoItems;
    },
    [Constant.GET_TODO]: (state, payload) => {
      store.state.todo = payload.todo;
    }
  }
});
export default store;
