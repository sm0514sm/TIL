<template>
  <div>
    <br />
    <h2>상세보기</h2>
    <table>
      <tr>
        <td>No</td>
        <td>{{ todo.no }}</td>
      </tr>
      <tr>
        <td>content</td>
        <td>{{ todo.content }}</td>
      </tr>
      <tr>
        <td>userId</td>
        <td>{{ todo.userId }}</td>
      </tr>
      <tr>
        <td>writeDate</td>
        <td>{{ todo.writeDate }}</td>
      </tr>
      <tr>
        <td>endDate</td>
        <td>{{ todo.endDate }}</td>
      </tr>
      <tr>
        <td>done</td>
        <td>{{ todo.done }}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import Constant from "../Constant";

export default {
  computed: {
    todo() {
      return this.$store.state.todo;
    }
  },
  created() {
    this.getTodo(this.$route.params.no);
  },
  methods: {
    getTodo(no) {
      this.$store.dispatch(Constant.GET_TODO, { no });
    }
  }
};
</script>

<style scoped>
table {
  margin: auto;
  width: 50%;
  border-top: 1px solid #444444;
  border-collapse: collapse;
}
td {
  border-bottom: 1px solid #444444;
  padding: 10px;
}
</style>
