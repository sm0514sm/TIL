<template>
  <div>
    <h2>사원 리스트</h2>
    <table>
      <tr>
        <td>사원</td>
        <td>메일ID</td>
        <td>입사일</td>
        <td>매니저</td>
        <td>직급</td>
        <td>부서ID</td>
        <td>연봉</td>
        <td>님 사퇴?</td>
      </tr>
      <tr v-for="employee in employees" v-bind:key="employee.id">
        <td>{{ employee.name }}</td>
        <td>{{ employee.mailid }}</td>
        <td>{{ employee.start_date }}</td>
        <td>{{ employee.manager_id }}</td>
        <td>{{ employee.title }}</td>
        <td>{{ employee.dept_id }}</td>
        <td>{{ employee.salary }}</td>
        <td>
          <input
            type="button"
            @click="removeEmployee(employee.id)"
            value="ㄱㄱ"
          />
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import bus from "../eventbus";
import http from "../http-common";

export default {
  name: "EmployeeList",
  data() {
    return {
      employees: []
    };
  },
  created() {
    this.getEmployeeList();
    bus.$on("getEmployeeList", this.getEmployeeList);
  },
  methods: {
    getEmployeeList() {
      http
        .get("/api/findAllEmployees/")
        .then(response => {
          this.employees = response.data.data;
          bus.$emit("getEmployeeList"); // 이벤트 발생시키기
        })
        .catch(exp => alert("보기에 실패하였습니다." + exp));
    },
    removeEmployee(id) {
      http
        .delete("/api/deleteEmployee/" + id)
        .then()
        .catch(exp => alert("삭제에 실패하였습니다." + exp));
    }
  }
};
</script>

<style scoped></style>
