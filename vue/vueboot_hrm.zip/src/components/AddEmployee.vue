<template>
  <div>
    <table asign="center">
      <tr>
        <td>사원 :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.name" />
        </td>
      </tr>
      <tr>
        <td>메일ID :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.mailid" />
        </td>
      </tr>
      <tr>
        <td>입사일 :</td>
        <td>
          <input type="date" class="inputBox" v-model="employee.start_date" />
        </td>
      </tr>
      <tr>
        <td>매니저 :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.manager_id" />
        </td>
      </tr>
      <tr>
        <td>직급 :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.title" />
        </td>
      </tr>
      <tr>
        <td>부서ID :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.dept_id" />
        </td>
      </tr>
      <tr>
        <td>연봉 :</td>
        <td>
          <input type="text" class="inputBox" v-model="employee.salary" />
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <input
            type="button"
            value="입력"
            class="modifyBtn"
            @click="addEmployee"
          />
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
import http from "../http-common";
import bus from "../eventbus";

export default {
  data() {
    return {
      employee: {
        commission_pct: 0,
        dept_id: null,
        mailid: "",
        manager_id: null,
        name: "",
        salary: null,
        start_date: "",
        title: ""
      }
    };
  },
  methods: {
    addEmployee() {
      http
        .post("/api/addEmployee/", this.employee)
        .then(() => {
          bus.$emit("getEmployeeList"); // 이벤트 발생시키기
          this.clear();
        })
        .catch(exp => alert("처리에 실패하였습니다." + exp));
    },
    clear() {
      this.employee.dept_id = "";
      this.employee.mailid = "";
      this.employee.manager_id = "";
      this.employee.name = "";
      this.employee.salary = "";
      this.employee.start_date = "";
      this.employee.title = "";
    }
  }
};
</script>

<style scoped>
input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}
.addContainer {
  float: right;
  background: linear-gradient(to right, #6478fb, #8763fb);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.addContainer2 {
  float: right;
  background: linear-gradient(to right, #647811, #527810);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}
.modifyBtn,
.addBtn {
  color: white;
  vertical-align: middle;
}
</style>
