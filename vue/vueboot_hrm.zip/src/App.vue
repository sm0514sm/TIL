<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" />
    <add-employee></add-employee>
    <employee-list></employee-list>
  </div>
</template>

<script>
import AddEmployee from "./components/AddEmployee";
import EmployeeList from "./components/EmployeeList";

export default {
  name: "app",
  components: {
    AddEmployee,
    EmployeeList
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
