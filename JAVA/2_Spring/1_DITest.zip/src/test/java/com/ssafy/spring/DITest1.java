package com.ssafy.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.dto.Board;

public class DITest1 {

	public static void main(String[] args) {
		
		/*Spring Container 생성*/
		BeanFactory container = new ClassPathXmlApplicationContext("com/ssafy/config/beans1.xml");
		System.out.println("Spring container loading 완료");
		
		
		/* getBean(String name)
		 * name이나 id에 해당하는 작가를 찾아 Container에 출력
		 * 형변환을 해야한다.
		 *  */
//		Board board = (Board)container.getBean("board");
//		System.out.println(board);
		
//		/* getBean(Class class)
//		 * name이나 id에 해당하는 작가를 찾아 Container에 출력
//		 * 형변환을 필요없다.
//		 * Container에 동일한 타입의 객체가 2개이상 등록된 경우 error 발생
//		 *  */
//		Board board = container.getBean(Board.class);
//		System.out.println(board);
		
		/* getBean(String name, Class class)
		 * name이나 id에 해당하는 작가를 찾아 Container에 출력
		 * 형변환을 필요없다.
		 * Container에 동일한 타입의 객체가 2개이상 등록된 경우 처리가능
		 *  */
		Board board1 = container.getBean("board", Board.class);
		Board board2 = container.getBean("board", Board.class);
		System.out.println(board1.hashCode());	
		System.out.println(board2.hashCode());	//singleton(default)는 getBean해도 한번만 생성
		Board b1 = container.getBean("board2", Board.class);
		Board b2 = container.getBean("board2", Board.class);
		System.out.println(b1.hashCode());	
		System.out.println(b2.hashCode());	//prototype은 getBean할 때마다 새로운 객체
	}

}
