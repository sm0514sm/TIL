package com.ssafy.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.service.BoardService;
import com.ssafy.model.service.MemberService;

public class DITest3 {

	public static void main(String[] args) {
		BeanFactory con = new ClassPathXmlApplicationContext("com/ssafy/config/beans3.xml");
		BoardService bservice = con.getBean(BoardService.class);
		System.out.println(bservice.search("1"));
		
		MemberService mservice = con.getBean(MemberService.class);
		System.out.println(mservice.search("ssafy"));
	}
}
