package com.ssafy.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.model.dto.Board;

@Controller
public class MainController {
	
	/*
	 * 1. Mapping
	 * 		- 요청 url에 따른 처리할 controller method를 mapping 시킨다
	 * 		@RequestMapping(value='url' or '{url, ... }', method=RequestMethod.XXXX)
	 * 		* method
	 * 			- 요청 방식
	 * 			- 어떤 방식으로 요청하던 모두 처리
	 * 		* value
	 * 			- 요청 url
	 * 			- 1개일 경우 value='url'
	 * 			- 여러개일 경우 value='{url, ...}'
	 *  		- 다른 속성이 없으면 생략이 가능하다
	 *  
	 *  Spring 4.x에서 추가된 요청 방식 제거버젼	=> pop.xml에서 spring version을 변경
	 *  	@getMapping("url")	: get방식으로 요청된 경우
	 *  	@PostMapping("url")	: post방식으로 요청된 경우
	 *  	...
	 *-------------------------------------------------------------------------------------------*
	 * 2. 인자 : 요청 데이터
	 * 		2.1 String
	 * 			- 인자명으로 요청데이터를 추출해서 전달
	 * 			ex) String msg
	 * 			String msg = request.getParameter("msg");							이거와 똑같다.
	 *   		- 인자명에 해당하는 요청데이터가 요청 packet에 없어도 (NULL), 혹은
	 *  		  요청 데이터명은 있지만 데이터가 없어도 (공백) ERROR가 발생하지 않음!!
	 *  
	 *  	2.2 Primitive Type
	 *  		- 인자명으로 요청데이터를 추출해서 format으로 변경 후 전달
	 *			ex) int price
	 *			int price = Integer.parseInt(request.getParameter("price"));		이거와 똑같다.
	 *			- 인자명에 해당하는 요청데이터가 요청 packet에 없으면 500
	 *			  요청데이터명은 있지만 데이터가 없거나 format이 다른경우 400 ERROR 발생
	 *
	 *		2.3 @RequestParam    *-- String or Primitive --*
	 *			@RequestParam(value='요청데이터명', require, defaultValue)
	 * 	  		- value : 추출할 요청 테이터명
	 * 			- require
	 * 				-- true  : 요청 데이터가 없는 경우 ERROR 발생
	 * 			- defaultValue : 요청 데이터가 없는 경우 지정한 값으로 전달  
	 * 
	 * 		2.4 DTO (Data Transfer Object)
	 * 			- 인자의 객체를 기본 생성자로 생성 후 객체의 모든 속성을 요청 패키지에서 데이터를 추출 후
	 * 			  setter 메서드로 데이터 설정을 한다. 
	 * 			  마지막으로 첫글자를 소문자로 한 클래스명으로 request에 저장한다.
	 * 			ex) Board b
	 * 			*----------- 이거를 전부다 한번에 해준다 -------------*
	 * 			Board b = new Board();
	 * 			b.setNo(Integer.parseInt(request.getParameter("no")));
	 * 			b.setId(request.getParameter("id"));
	 * 			b.setTitle(request.getParameter("title"));
	 * 			b.setRegDate(request.getParameter("regdate"));
	 * 			b.setContents(request.getParameter("contents"));
	 * 			request.setAttribute("board", b);
	 * 			
	 * 		2.5 @ModelAttribute("") DTO
	 * 			- 인자의 객체를 기본 생성자로 생성 후 객체의 모든 속성을 요청 패키지에서 데이터를 추출 후
	 * 			  setter 메서드로 데이터 설정을 한다.
	 * 			  마지막으로 지정한 이름으로 request에 저장한다.
	 * 			ex) Board b
	 * 			*----------- 이거를 전부다 한번에 해준다 -------------*
	 * 			Board b = new Board();
	 * 			b.setNo(Integer.parseInt(request.getParameter("no")));
	 * 			b.setId(request.getParameter("id"));
	 * 			b.setTitle(request.getParameter("title"));
	 * 			b.setRegDate(request.getParameter("regdate"));
	 * 			b.setContents(request.getParameter("contents"));
	 * 			request.setAttribute("우리가 지정한 이름", b);
	 * 
	 * 		2.6 @RequestParam Map
	 * 			- 요청 패킷에서 모든 요청 데이터를 추출해서
	 * 			  Map에 요청데이터명이 Key, 요청데이터가 Value가 해서 데이터 세팅 후 전달
	 * 			  DTO를 만들지 않고도 할 수 있다.
	 * 
	 * 		2.7 Servlet API를 인자로 
	 * 			- HTTPServletRequest, HTTPServletResponse, HTTPSession
	 * 			, Reader, Writer, ServletInputStream, ServletOutputStream 
	 * 			단) Servlet module 3.0 이상인 경우 ServletContext를 인자로 받을 수 있다.
	 * 
	 * 		2.8 Model을 인자로
	 * 			- Model은 인터페이스이므로 인자로만 받을 수 있다.
	 * 			- Service를 수행한 결과를 Model에 저장하면 request에 저장한 효과이다.
	 * 			- 선생님은 비추함
	 * 
	 * 		2.9 MultipartFile
	 * 			- 업로드된 파일 정보
	 * 			- pom.xml에 파일과 관련된 라이브러리를 추가
	 * 			  commons-io-xxx.jar
	 * 			  commons-fileupload-xxx.jar
	 * 			- web을 위한 bean configuration에 multipartResolver를 추가
	 * 			  multipartResolver는 요청 데이터에서 파일 정보만 추출해서 MultipartFile로 전달
	 *-----------------------------------------------------------------------------------------------*
	 * 	3. 리턴 : View에 대한 정보
	 * 		3.1 string
	 * 		  	- 이동할 View에 대한 url을 문자열로
	 * 			  forward 	: "url" or "forward:url"
	 * 			  redirect	: "redirect:url"
	 * 
	 * 		3.2 void
	 * 			- 요청 url에서 .이후를 제거한 이름을 view로 인식해서
	 * 			  등록된 이름의 view로 이동		
	 * 			- ViewResolver를 설정해서 view 이름을 완성해야한다.
	 * 			ex) @PostMapping("insertBoard.log")인 경우
	 * 				view 이름은 insertBoard	
	 * 
	 * 		3.3 DTO or Map or 집합객체(배열, 컬렉션) ==> REST Full
	 * 			- XML이나 JSON데이터로 출력
	 * 			- jackson-bind-xxx.jar
	 * 
	 * 		3.4 ModelAndView
	 * 			- 모델을 수행한 결과 정보와 View 정보를 표현하는 객체
	 * 
	 *---------------------------------------------------------------------------------------*
	 *
	 * 	4. 예외 처리
	 * 	- 현재 컨트롤러에서 발생한 오류를 처리
	 *    형식]
	 * 	  @ExceptionHandler
	 *    public 리턴타입 함수명(Exception e){ //무조건 인자로 Exception만 받아야함
	 *    
	 *    }
	 */
	
//	@RequestMapping("hello.do")		// 요청 url
//	1.
//	@GetMapping("hello.do")
//	public String hello() {
//		return "hello.jsp";			// forward로 이동
//	}
	
//	2.1 인자로 String을 받는 경우
//	@GetMapping("hello.do")
//	public String hello(String msg) {
//		System.out.println("msg : " + msg);
//		return "hello.jsp";			// forward로 이동
//	}
	
//	2.2 인자로 Primitive Type를 받는 경우
//	@GetMapping("hello.do")
//	public String hello(int msg) {
//		System.out.println("msg : " + msg);
//		return "hello.jsp";			// forward로 이동
//	}
	
//	2.3 @RequestParam 이용
//	required=true > 문자열이여도 데이터 전달 안되면 error
	@GetMapping("hello.do")
	public String hello(@RequestParam(required=true, defaultValue="5000") int msg) {
		System.out.println("msg : " + msg);
		return "hello.jsp";			// forward로 이동
	}
	
//	2.4 DTO를 인자로 받을때!
//	@PostMapping("insertBoard.log")
//	public String insertBoard(Board b) {
//		System.out.println("게시글 정보 : " + b);
//		return "Result1.jsp";
//	}
	
//	2.5 @ModelAttribute 로 DTO를 인자로 받을 때
//	@PostMapping("insertBoard.log")
//	public String insertBoard(@ModelAttribute("b") Board board) {
//		System.out.println("게시글 정보 : " + board);
//		return "Result2.jsp";
//	}
	
//	2.6 2.7 예제
//	@PostMapping("insertBoard.log")
//	public String insertBoard(HttpServletRequest request, @RequestParam Map<String, String> map) {
//		System.out.println("게시글 정보 : " + map);
//		request.setAttribute("board", map);
//		return "Result1.jsp";
//	}
	
//	2.6 2.8 예제
	@PostMapping("insertBoard.log")
	public String insertBoard(Model model, @RequestParam Map<String, String> map) {
		System.out.println("게시글 정보 : " + map);
		model.addAttribute("board", map);
		return "Result1.jsp";
	}
	
//	3.2 리턴을 void인 경우 => InternalRerourceViewResolver를 설정해야한다.
	@GetMapping("showMessage.do")
	public void showMessage(String msg, Model model) {
		model.addAttribute("message", msg);
	}
	
//	3.3 DTO 출력 = > JSON으로 출력한다.
	@GetMapping("rest.do")
	@ResponseBody
	public Board rest() {
		return new Board("ssafy", "처음하는", "spring");
	}
	
	
//	4. 예외처리
	@ExceptionHandler
	public ModelAndView handler(Exception e) {
		ModelAndView mav = new ModelAndView("ErrorHandler.jsp");
		mav.addObject("msg", e.getMessage());
		return mav;
	}
	
	@GetMapping("restList.do")
	@ResponseBody
	public List<Board> restList(){
		ArrayList<Board> boards = new ArrayList<Board>(2);
		boards.add(new Board("ssafy", "처음1", "spring1"));
		boards.add(new Board("ssafy", "처음2", "spring2"));
		return boards;
	}
	
	
	@GetMapping("error.do")
	public String error() {
		System.out.println("test");
		System.out.println(256/0);
		return "result1.jsp";
	}
	
}

















